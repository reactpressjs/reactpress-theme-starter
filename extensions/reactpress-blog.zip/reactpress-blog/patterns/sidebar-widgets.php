<?php
/**
 * Title: Sidebar widgets
 * Slug: reactpress-blog/sidebar-widgets
 * Categories: reactpress-blog, widgets
 * Inserter: yes
 * Description: Recommended readings and colorful tags sidebar.
 *
 * @package ReactPress_Blog
 */

?>
<!-- wp:group {"tagName":"aside","className":"rp-sidebar","layout":{"type":"default"}} -->
<aside class="wp-block-group rp-sidebar">
	<!-- wp:reactpress-blog/recommend /-->
	<!-- wp:reactpress-blog/tags /-->
	<!-- wp:reactpress-blog/about {"variant":"sidebar"} /-->
</aside>
<!-- /wp:group -->
