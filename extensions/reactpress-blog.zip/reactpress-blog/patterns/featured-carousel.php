<?php
/**
 * Title: Featured carousel
 * Slug: reactpress-blog/featured-carousel
 * Categories: reactpress-blog, featured
 * Inserter: yes
 * Description: Hero carousel of sticky or recent posts with cover images.
 *
 * @package ReactPress_Blog
 */

?>
<!-- wp:group {"className":"rp-featured","layout":{"type":"default"}} -->
<div class="wp-block-group rp-featured">
	<!-- wp:reactpress-blog/carousel /-->
</div>
<!-- /wp:group -->
