/**
 * ReactPress Blog — dynamic block editor previews (ServerSideRender).
 */
(function (wp) {
	'use strict';

	if (!wp || !wp.blocks || !wp.element || !wp.blockEditor) {
		return;
	}

	var registerBlockType = wp.blocks.registerBlockType;
	var createElement = wp.element.createElement;
	var useBlockProps = wp.blockEditor.useBlockProps;
	var ServerSideRender =
		(wp.serverSideRender && (wp.serverSideRender.default || wp.serverSideRender)) || null;

	var heartIcon =
		'<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>';
	var eyeIcon =
		'<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';

	function formatError(error) {
		if (!error) {
			return 'Unknown error';
		}
		if (typeof error === 'string') {
			return error;
		}
		if (error.message && typeof error.message === 'string') {
			return error.message;
		}
		try {
			return JSON.stringify(error);
		} catch (e) {
			return 'Request failed';
		}
	}

	function Preview(blockName, fallback) {
		if (!ServerSideRender) {
			return fallback || createElement('div', { className: 'rp-block-preview' }, blockName);
		}

		return createElement(ServerSideRender, {
			block: blockName,
			ErrorResponsePlaceholder: function (props) {
				return createElement(
					'div',
					{ className: 'rp-block-preview rp-block-preview--error' },
					'Error loading block: ' + formatError(props && props.response ? props.response : props)
				);
			},
		});
	}

	var blocks = [
		{ name: 'reactpress-blog/header-tools', title: 'Header Tools', icon: 'admin-users' },
		{ name: 'reactpress-blog/carousel', title: 'Featured Carousel', icon: 'images-alt2' },
		{ name: 'reactpress-blog/category-menu', title: 'Category Menu', icon: 'category' },
		{ name: 'reactpress-blog/recommend', title: 'Recommended Readings', icon: 'heart' },
		{ name: 'reactpress-blog/tags', title: 'Tags Cloud', icon: 'tag' },
		{
			name: 'reactpress-blog/about',
			title: 'About',
			icon: 'info-outline',
			attributes: {
				variant: { type: 'string', default: 'footer' },
			},
		},
		{ name: 'reactpress-blog/card-stats', title: 'Card Stats', icon: 'chart-bar', preview: 'stats' },
		{
			name: 'reactpress-blog/infinite-scroll',
			title: 'Infinite Scroll',
			icon: 'image-flip-vertical',
			preview: 'infinite',
		},
	];

	blocks.forEach(function (block) {
		var settings = {
			apiVersion: 3,
			title: block.title,
			description: 'ReactPress Blog dynamic block',
			category: 'widgets',
			icon: block.icon,
			supports: {
				html: false,
				align: false,
				reusable: false,
				multiple: block.preview !== 'infinite',
			},
			edit: function (editProps) {
				var props = useBlockProps({ className: 'rp-block-preview' });

				if (block.preview === 'stats') {
					return createElement('div', props, createElement('span', {
						className: 'rp-card-stats',
						dangerouslySetInnerHTML: {
							__html:
								'<span class="rp-card-stats__item">' +
								heartIcon +
								'<span>0</span></span><span class="rp-card-stats__sep" aria-hidden="true">·</span><span class="rp-card-stats__item">' +
								eyeIcon +
								'<span>12</span></span>',
						},
					}));
				}

				if (block.preview === 'infinite') {
					return createElement(
						'div',
						props,
						createElement(
							'div',
							{ className: 'rp-infinite-scroll rp-infinite-scroll--editor' },
							createElement(
								'p',
								{ className: 'rp-infinite-scroll__label' },
								'Infinite scroll — loads more posts as visitors scroll'
							)
						)
					);
				}

				if (block.attributes && ServerSideRender) {
					return createElement(
						'div',
						props,
						createElement(ServerSideRender, {
							block: block.name,
							attributes: (editProps && editProps.attributes) || {},
						})
					);
				}

				return createElement('div', props, Preview(block.name));
			},
			save: function () {
				return null;
			},
		};

		if (block.attributes) {
			settings.attributes = block.attributes;
		}

		try {
			if (wp.blocks.getBlockType(block.name)) {
				wp.blocks.unregisterBlockType(block.name);
			}
		} catch (e) {
			/* ignore */
		}

		registerBlockType(block.name, settings);
	});
})(window.wp);
